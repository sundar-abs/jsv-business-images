---
name: Corporate Precision Tech
colors:
  surface: '#f9f9ff'
  surface-dim: '#d9d9e1'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fb'
  surface-container: '#ededf5'
  surface-container-high: '#e7e7ef'
  surface-container-highest: '#e1e2ea'
  on-surface: '#191c21'
  on-surface-variant: '#424752'
  inverse-surface: '#2e3036'
  inverse-on-surface: '#f0f0f8'
  outline: '#737783'
  outline-variant: '#c2c6d4'
  surface-tint: '#215cb2'
  primary: '#00397a'
  on-primary: '#ffffff'
  primary-container: '#054fa4'
  on-primary-container: '#a9c5ff'
  inverse-primary: '#acc7ff'
  secondary: '#5e5e5f'
  on-secondary: '#ffffff'
  secondary-container: '#e0dfdf'
  on-secondary-container: '#626363'
  tertiary: '#003e60'
  on-tertiary: '#ffffff'
  tertiary-container: '#005683'
  on-tertiary-container: '#8dcbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#acc7ff'
  on-primary-fixed: '#001a40'
  on-primary-fixed-variant: '#004491'
  secondary-fixed: '#e3e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#91ccff'
  on-tertiary-fixed: '#001e31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f9f9ff'
  on-background: '#191c21'
  surface-variant: '#e1e2ea'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  caption:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The brand personality is authoritative, reliable, and technologically advanced. It is designed for high-stakes business environments where precision and trust are paramount. The design system follows a **Corporate Modern** aesthetic with a lean toward **High-Contrast Minimalism**. 

The UI should feel expansive and organized, utilizing significant whitespace to emphasize key data points and strategic messaging. Every element is intentional, avoiding unnecessary ornamentation to ensure the focus remains on service excellence and technical proficiency. The emotional response should be one of confidence and structural integrity.

## Colors

The palette is anchored by **Deep Blue**, representing stability and corporate depth. **Sky Blue** serves as a high-action accent for interactive elements and highlights, providing a "tech-forward" spark against the traditional corporate base. 

- **Primary (#054fa4):** Used for main navigation, primary buttons, and authoritative headers.
- **Secondary (#a8a8a8):** Utilized for borders, disabled states, and auxiliary information to maintain a neutral balance.
- **Tertiary (#0fa0ed):** Reserved for links, status indicators, and call-to-action accents.
- **Neutral/Background (#ffffff):** The primary canvas, ensuring maximum legibility and a clinical, professional feel.

## Typography

This design system utilizes **Hanken Grotesk** across all roles to maintain a unified, engineered feel. The typeface’s sharp geometry and contemporary proportions align with the tech-forward narrative.

- **Headlines:** Set with tight letter-spacing and heavy weights to command attention and project authority.
- **Body Text:** Optimized for readability with generous line-heights (1.6) to prevent eye fatigue during long-form technical reading.
- **Labels:** Set in uppercase with increased letter-spacing to distinguish functional UI elements from narrative content.

## Layout & Spacing

The design system employs a **Fixed Grid** philosophy for desktop to maintain a structured, editorial feel, transitioning to a **Fluid Grid** for mobile devices.

- **Grid:** A 12-column grid is used for desktop (1280px max-width) with 24px gutters.
- **Rhythm:** An 8px linear scale governs all spatial relationships. 
- **Breakpoints:** 
  - Mobile: < 768px (4 columns, 16px margins)
  - Tablet: 768px - 1024px (8 columns, 32px margins)
  - Desktop: > 1024px (12 columns, 64px margins)

## Elevation & Depth

To maintain a "sharp" and professional tech aesthetic, depth is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surface Levels:** The base background is pure white (#FFFFFF). Elevated elements like cards use a subtle 1px border (#A8A8A8 at 30% opacity) rather than a shadow.
- **Interactive Depth:** Only the primary action elements (e.g., "Get Started" buttons) may use a very crisp, short shadow (4px blur, 10% opacity black) to indicate pressability.
- **Separation:** Use Grey (#A8A8A8) hair-lines (1px) to divide content sections, reinforcing the "engineered" look.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding takes the "edge" off the industrial feel while remaining significantly sharper than consumer-grade social apps. 

- **Components:** Buttons and input fields use a 4px (0.25rem) radius.
- **Containers:** Large cards or sections use a 8px (0.5rem) radius to provide a clear but disciplined container for complex data.
- **Icons:** Use "sharp" or "linear" icon sets to match the precision of the typography.

## Components

- **Buttons:** 
  - *Primary:* Deep Blue (#054fa4) background, white text, 4px radius. 
  - *Secondary:* Transparent background, Deep Blue 1px border.
  - *Tertiary/Ghost:* Sky Blue (#0fa0ed) text, no background.
- **Inputs:** 1px solid Grey (#a8a8a8) border. On focus, the border transitions to Sky Blue (#0fa0ed) with a subtle 2px outer glow.
- **Chips:** Solid Grey (#a8a8a8) at 10% opacity with dark text for metadata; use Sky Blue for "Active" status chips.
- **Cards:** White background, 1px light grey border. No shadow. Cards should have a 32px internal padding for a spacious, high-end feel.
- **Data Tables:** High-density, using 1px horizontal dividers only. Header rows should be subtly tinted with a light version of the secondary grey to anchor the data.